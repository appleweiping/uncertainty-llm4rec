# Framework-Observation-Day1f Self-Consistency Confidence Report

## Scope

Day1f is a local Beauty 100-user valid/test smoke with complete six-candidate pools. It does not train, use evidence, use CEP, call external APIs, or run four domains.

## Self-Consistency Signal

- test AUROC: `0.53713`
- test ECE/Brier: `0.17099999999999999` / `0.1706`
- test correctness AUROC: `0.5564192949907235`
- test parse success rate: `1.0`

## Ranking

- self-consistency test MRR / random MRR: `0.8333333333333334` / `0.4083333333333333`
- self-consistency test HR@1 / random HR@1: `0.69` / `0.16666666666666666`
- self-consistency test NDCG@3 / random NDCG@3: `0.8764231408571498` / `0.35515495892857624`

## Logit Comparison

See `data_done/framework_observation_day1f_logit_vs_self_consistency_comparison.csv` for same-subset comparison.

## Recommendation

`move_to_pair_or_list_context_audit`
